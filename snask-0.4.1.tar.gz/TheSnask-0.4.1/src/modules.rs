use crate::ast::Program;
use crate::packages::{get_frameworks_dir, get_packages_dir};
use crate::parser::parse_program;
use std::fs;
use std::path::{Path, PathBuf};

pub fn is_native_module(name: &str) -> bool {
    matches!(
        name,
        "gui"
            | "os"
            | "sfs"
            | "string"
            | "math"
            | "json"
            | "http"
            | "collections"
            | "io"
            | "sys"
            | "sqlite"
            | "zlib"
    )
}

pub fn load_module(path: &str) -> Result<Program, String> {
    load_module_from(Path::new("."), path)
}

pub fn load_module_from(base_dir: &Path, path: &str) -> Result<Program, String> {
    // 1. Check for native modules that don't have a .snask file.
    if is_native_module(path) {
        return Ok(Vec::new()); // It's a valid module, but it's part of the runtime.
    }

    // 2. Try local project dir first (relative to the importing file)
    let local_path = if path.ends_with(".snask") {
        base_dir.join(path)
    } else {
        base_dir.join(format!("{}.snask", path))
    };
    if local_path.exists() {
        return read_and_parse_module(&local_path);
    }

    // 3. Try global packages dir (~/.snask/packages/)
    let global_packages_dir = get_packages_dir();
    let global_path = if path.ends_with(".snask") {
        global_packages_dir.join(path)
    } else {
        global_packages_dir.join(format!("{}.snask", path))
    };
    if global_path.exists() {
        return read_and_parse_module(&global_path);
    }

    // 4. Try global frameworks dir (~/.snask/frameworks/)
    let global_frameworks_dir = get_frameworks_dir();

    let fw_path = if path.ends_with(".snask") {
        global_frameworks_dir.join(path)
    } else {
        global_frameworks_dir.join(format!("{}.snask", path))
    };

    if fw_path.exists() {
        return read_and_parse_module(&fw_path);
    }

    Err(format!(
        "Module '{}' not found. Searched in '{}', packages, and frameworks.",
        path,
        base_dir.display()
    ))
}

pub fn load_from_import(
    base_dir: &Path,
    from: &[String],
    is_current_dir: bool,
    module: &str,
) -> Result<(Program, PathBuf), String> {
    let dir = if is_current_dir {
        base_dir.to_path_buf()
    } else {
        from.iter()
            .fold(base_dir.to_path_buf(), |acc, s| acc.join(s))
    };
    let file_path = dir.join(format!("{}.snask", module));
    if !file_path.exists() {
        return Err(format!(
            "Module '{}' not found at {}",
            module,
            file_path.display()
        ));
    }
    let program = read_and_parse_module(&file_path)?;
    Ok((program, file_path))
}

fn read_and_parse_module(path: &Path) -> Result<Program, String> {
    let source = fs::read_to_string(path)
        .map_err(|e| format!("Failed to read module {}: {}", path.display(), e))?;

    parse_program(&source).map_err(|e| format!("Syntax error in module {}: {}", path.display(), e))
}
