#!/bin/bash
python3 snaskpack.py "$@"
